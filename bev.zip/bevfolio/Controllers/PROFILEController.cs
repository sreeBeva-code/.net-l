﻿using bevfolio.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;

namespace bevfolio.Controllers
{
    public class PROFILEController : Controller
    {
        // GET: PROFILE
        public ActionResult Index()
        {
          
                return View();
        }
        public ActionResult Profile()
        {
            
            Student s1 = new Student();
            s1.DOB = "02/05/01:" ;
            s1.Name = "Bevan";
            s1.NATION = "BANGLADESH";
            s1.b_group = "O+";
            
            s1.Hobbies = new List<string> { "Reading", "Gaming", "Traveling" };
            
          
            return View(s1);
        }
    }
        
}