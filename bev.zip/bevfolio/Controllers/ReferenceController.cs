﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace bevfolio.Controllers
{
    public class ReferenceController : Controller
    {
        // GET: Reference
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Reference() {


            string name = "TANVIR AHMED ";
            string email = "tanvir@gamil.com";
            string regic = "Asistence lecturer ";
            ViewBag.Name = name;
            ViewBag.email = email;
            ViewBag.regc = regic;
            return View();


            
        }
    }
}