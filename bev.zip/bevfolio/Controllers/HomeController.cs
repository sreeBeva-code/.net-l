﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace bevfolio.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Home()
        {

            string name = "BEVAN SAHA";
            string email = "bevansaha@gamil.com";
            string Bio = "MY NAME IS BEVAN SAHA , I AM NOW 11th sem ";
            ViewBag.Name = name;
            ViewBag.email = email;
            ViewBag.Bio = Bio;
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}