﻿using bevfolio.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace bevfolio.Controllers
{
    public class EducationController : Controller
    {
        // GET: Education
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult Education()

        {


            Edu[] educations = new Edu[]
      {
            new Edu
            {
                Title = "BSc",
                Ins = "AIUB",
                Year = "3rd"
            },
            new Edu
            {
                Title = "HSC",
                Ins = "BAGHC",
                Year = "2018"
            },
            new Edu
            {
                Title = "SSC",
                Ins = "MGHS",
                Year = "2017"
            }
      };

            return View(educations);
            /*
                        Edu s2 = new Edu();
                        s2.Title = "BSc";
                        s2.Ins = "AIUB";
                        s2.Year = "3rd";

                        Edu s3 = new Edu();
                        s3.Title = "HSC";
                        s3.Ins = "BAGHC";
                        s3.Year = "2018";

                        Edu s4 = new Edu();

                        s4.Title = "ssc";
                        s4.Ins = "MGHS";
                        s4.Year = "2017";


                        s2.Bsc = new List<string> { "AIUB", "#rd year" };
                        s2.HSC = new List<string> { "isn", "2018" };
                        s2.SCC = new List<string> { "isn", "2016" };
                        ViewBag.BscDetails = s2.Bsc;
                        ViewBag.HSCDetails = s2.HSC;
                        ViewBag.SCCDetails = s2.SCC;

                  */
           
        }
    }
}