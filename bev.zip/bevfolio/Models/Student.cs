﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace bevfolio.Models
{
    public class Student
    {
       
     
        
        public string Name { get; set; }
        public string DOB { get; set; }
        public string NATION { get; set; }
        public string b_group { get; set;}
       public List<string> Hobbies { get; set; }







    }
}