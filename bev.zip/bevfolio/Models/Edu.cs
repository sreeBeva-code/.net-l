﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace bevfolio.Models
{
    public class Edu
    {
        public string Title { get; set; }
        public string Ins { get; set; }
        public string Year { get; set; }

    }
}